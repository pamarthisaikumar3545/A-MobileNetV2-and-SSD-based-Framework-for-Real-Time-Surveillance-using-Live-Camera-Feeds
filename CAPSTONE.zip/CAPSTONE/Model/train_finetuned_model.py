"""
Fine-Tuned Security Camera Model Training Script
This script trains a MobileNetV2 + SSD model on the security dataset
and exports it to TensorFlow.js format for use in the web application.
"""

import tensorflow as tf
import tensorflowjs as tfjs
import numpy as np
import pandas as pd
import os
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Dropout
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau

# Configuration
IMG_SIZE = 416
BATCH_SIZE = 16
EPOCHS = 50
LEARNING_RATE = 0.0001

# Security-specific classes
SECURITY_CLASSES = [
    'person',
    'knife',
    'scissors',
    'baseball_bat',
    'bottle',
    'backpack',
    'handbag',
    'suitcase'
]

NUM_CLASSES = len(SECURITY_CLASSES)

def load_dataset():
    """Load and preprocess the security dataset"""
    print("Loading dataset...")
    
    # Load CSV with image paths and labels
    df = pd.read_csv('../Dataset/dataset.csv')
    
    # Filter for security-relevant classes only
    df = df[df['class'].isin(SECURITY_CLASSES)]
    
    print(f"Loaded {len(df)} samples")
    print(f"Class distribution:\n{df['class'].value_counts()}")
    
    return df

def create_data_generator(df, batch_size=BATCH_SIZE):
    """Create data generator for training"""
    datagen = tf.keras.preprocessing.image.ImageDataGenerator(
        rescale=1./255,
        rotation_range=20,
        width_shift_range=0.2,
        height_shift_range=0.2,
        horizontal_flip=True,
        zoom_range=0.2,
        validation_split=0.2
    )
    
    train_generator = datagen.flow_from_dataframe(
        df,
        x_col='image_path',
        y_col='class',
        target_size=(IMG_SIZE, IMG_SIZE),
        batch_size=batch_size,
        class_mode='categorical',
        subset='training'
    )
    
    val_generator = datagen.flow_from_dataframe(
        df,
        x_col='image_path',
        y_col='class',
        target_size=(IMG_SIZE, IMG_SIZE),
        batch_size=batch_size,
        class_mode='categorical',
        subset='validation'
    )
    
    return train_generator, val_generator

def build_model():
    """Build MobileNetV2-based model for security detection"""
    print("Building model...")
    
    # Load pretrained MobileNetV2
    base_model = MobileNetV2(
        input_shape=(IMG_SIZE, IMG_SIZE, 3),
        include_top=False,
        weights='imagenet'
    )
    
    # Freeze base model layers initially
    base_model.trainable = False
    
    # Add custom classification head
    x = base_model.output
    x = GlobalAveragePooling2D()(x)
    x = Dense(512, activation='relu')(x)
    x = Dropout(0.5)(x)
    x = Dense(256, activation='relu')(x)
    x = Dropout(0.3)(x)
    predictions = Dense(NUM_CLASSES, activation='softmax')(x)
    
    model = Model(inputs=base_model.input, outputs=predictions)
    
    print(f"Model created with {NUM_CLASSES} classes")
    return model, base_model

def train_model(model, base_model, train_gen, val_gen):
    """Train the model in two phases"""
    
    # Phase 1: Train only the top layers
    print("\n=== Phase 1: Training classification head ===")
    model.compile(
        optimizer=Adam(learning_rate=LEARNING_RATE),
        loss='categorical_crossentropy',
        metrics=['accuracy', 'precision', 'recall']
    )
    
    callbacks = [
        EarlyStopping(patience=5, restore_best_weights=True),
        ModelCheckpoint('best_model_phase1.h5', save_best_only=True),
        ReduceLROnPlateau(factor=0.5, patience=3)
    ]
    
    history1 = model.fit(
        train_gen,
        validation_data=val_gen,
        epochs=20,
        callbacks=callbacks
    )
    
    # Phase 2: Fine-tune the entire model
    print("\n=== Phase 2: Fine-tuning entire model ===")
    base_model.trainable = True
    
    # Freeze early layers, fine-tune later layers
    for layer in base_model.layers[:100]:
        layer.trainable = False
    
    model.compile(
        optimizer=Adam(learning_rate=LEARNING_RATE/10),
        loss='categorical_crossentropy',
        metrics=['accuracy', 'precision', 'recall']
    )
    
    callbacks = [
        EarlyStopping(patience=7, restore_best_weights=True),
        ModelCheckpoint('best_model_phase2.h5', save_best_only=True),
        ReduceLROnPlateau(factor=0.5, patience=3)
    ]
    
    history2 = model.fit(
        train_gen,
        validation_data=val_gen,
        epochs=EPOCHS,
        callbacks=callbacks
    )
    
    return model, history1, history2

def evaluate_model(model, val_gen):
    """Evaluate model performance"""
    print("\n=== Evaluating Model ===")
    results = model.evaluate(val_gen)
    
    print(f"Validation Loss: {results[0]:.4f}")
    print(f"Validation Accuracy: {results[1]*100:.2f}%")
    print(f"Validation Precision: {results[2]:.4f}")
    print(f"Validation Recall: {results[3]:.4f}")
    
    return results

def export_to_tfjs(model, output_path='../public/models/finetuned'):
    """Export model to TensorFlow.js format"""
    print(f"\n=== Exporting to TensorFlow.js ===")
    print(f"Output path: {output_path}")
    
    # Create output directory if it doesn't exist
    os.makedirs(output_path, exist_ok=True)
    
    # Convert and save
    tfjs.converters.save_keras_model(model, output_path)
    
    print(f"Model exported successfully to {output_path}")
    print("Files created:")
    print(f"  - model.json")
    print(f"  - group1-shard*.bin")

def main():
    """Main training pipeline"""
    print("=" * 60)
    print("Fine-Tuned Security Camera Model Training")
    print("=" * 60)
    
    # Load dataset
    df = load_dataset()
    
    # Create data generators
    train_gen, val_gen = create_data_generator(df)
    
    # Build model
    model, base_model = build_model()
    
    # Train model
    model, history1, history2 = train_model(model, base_model, train_gen, val_gen)
    
    # Evaluate
    results = evaluate_model(model, val_gen)
    
    # Export to TensorFlow.js
    export_to_tfjs(model)
    
    print("\n" + "=" * 60)
    print("Training Complete!")
    print("=" * 60)
    print("\nNext steps:")
    print("1. Check the exported model in public/models/finetuned/")
    print("2. Restart the web application")
    print("3. Click 'Fine-Tuned Model' button to use your trained model")
    print("\nExpected performance:")
    print(f"  Accuracy: ~{results[1]*100:.1f}%")
    print(f"  Precision: ~{results[2]:.3f}")
    print(f"  Recall: ~{results[3]:.3f}")

if __name__ == '__main__':
    main()
