export interface ModelMetrics {
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  mAP: number;
  fps: number;
  inferenceTime: number;
  latency: number;
  objectsDetected: number;
  threatAlerts: number;
  totalFrames: number;
  truePositives: number;
  falsePositives: number;
  falseNegatives: number;
}

export interface MetricsHistory {
  timestamp: number;
  fps: number;
  accuracy: number;
  inferenceTime: number;
  objectCount: number;
}

export interface ModelComparison {
  pretrained: ModelMetrics;
  finetuned: ModelMetrics;
}

export type ModelType = 'pretrained' | 'finetuned';
