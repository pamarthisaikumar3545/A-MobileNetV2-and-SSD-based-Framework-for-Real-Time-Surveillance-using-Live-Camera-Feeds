import React from 'react';
import { ModelMetrics, ModelType } from '../types/metrics';
import { Activity, Zap, Target, TrendingUp, Clock, AlertCircle } from 'lucide-react';

interface MetricsDashboardProps {
  metrics: ModelMetrics;
  modelType: ModelType;
}

export function MetricsDashboard({ metrics, modelType }: MetricsDashboardProps) {
  const modelLabel = modelType === 'pretrained' ? 'Pretrained Model' : 'Fine-Tuned Model';

  const MetricCard = ({ 
    icon: Icon, 
    label, 
    value, 
    color 
  }: { 
    icon: any; 
    label: string; 
    value: string; 
    color: string;
  }) => (
    <div className={`bg-white rounded-lg p-4 shadow-md border-l-4 ${color}`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-slate-600 mb-1">{label}</p>
          <p className="text-2xl font-bold text-slate-900">{value}</p>
        </div>
        <Icon className={`w-8 h-8 ${color.replace('border-', 'text-')}`} />
      </div>
    </div>
  );

  return (
    <div className="mt-6 bg-slate-50 rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-slate-900">Live Performance Metrics</h2>
        <span className={`px-4 py-2 rounded-full text-sm font-semibold ${
          modelType === 'pretrained' 
            ? 'bg-blue-100 text-blue-800' 
            : 'bg-green-100 text-green-800'
        }`}>
          Active: {modelLabel}
        </span>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <MetricCard
          icon={Target}
          label="Accuracy"
          value={`${(metrics.accuracy * 100).toFixed(1)}%`}
          color="border-green-500"
        />
        <MetricCard
          icon={Activity}
          label="Precision"
          value={metrics.precision.toFixed(3)}
          color="border-blue-500"
        />
        <MetricCard
          icon={TrendingUp}
          label="Recall"
          value={metrics.recall.toFixed(3)}
          color="border-purple-500"
        />
        <MetricCard
          icon={Zap}
          label="F1 Score"
          value={metrics.f1Score.toFixed(3)}
          color="border-orange-500"
        />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <MetricCard
          icon={Activity}
          label="mAP@0.5"
          value={metrics.mAP.toFixed(3)}
          color="border-indigo-500"
        />
        <MetricCard
          icon={Zap}
          label="FPS"
          value={metrics.fps.toFixed(1)}
          color="border-cyan-500"
        />
        <MetricCard
          icon={Clock}
          label="Inference Time"
          value={`${metrics.inferenceTime.toFixed(0)}ms`}
          color="border-pink-500"
        />
        <MetricCard
          icon={Clock}
          label="Latency"
          value={`${metrics.latency.toFixed(0)}ms`}
          color="border-red-500"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white rounded-lg p-4 shadow-md">
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className="w-5 h-5 text-slate-600" />
            <p className="text-sm font-semibold text-slate-700">Detection Stats</p>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-sm text-slate-600">Objects Detected:</span>
              <span className="text-sm font-bold text-slate-900">{metrics.objectsDetected}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-slate-600">Threat Alerts:</span>
              <span className="text-sm font-bold text-red-600">{metrics.threatAlerts}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-slate-600">Total Frames:</span>
              <span className="text-sm font-bold text-slate-900">{metrics.totalFrames}</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg p-4 shadow-md">
          <div className="flex items-center gap-2 mb-2">
            <Target className="w-5 h-5 text-slate-600" />
            <p className="text-sm font-semibold text-slate-700">Detection Accuracy</p>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-sm text-slate-600">True Positives:</span>
              <span className="text-sm font-bold text-green-600">{metrics.truePositives}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-slate-600">False Positives:</span>
              <span className="text-sm font-bold text-orange-600">{metrics.falsePositives}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-slate-600">False Negatives:</span>
              <span className="text-sm font-bold text-red-600">{metrics.falseNegatives}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
