import React, { useEffect, useRef } from 'react';
import { MetricsHistory, ModelType } from '../types/metrics';

interface PerformanceChartsProps {
  pretrainedHistory: MetricsHistory[];
  finetunedHistory: MetricsHistory[];
  currentModel: ModelType;
}

export function PerformanceCharts({ 
  pretrainedHistory, 
  finetunedHistory,
  currentModel 
}: PerformanceChartsProps) {
  const fpsCanvasRef = useRef<HTMLCanvasElement>(null);
  const accuracyCanvasRef = useRef<HTMLCanvasElement>(null);
  const inferenceCanvasRef = useRef<HTMLCanvasElement>(null);
  const objectsCanvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    drawChart(
      fpsCanvasRef.current,
      pretrainedHistory,
      finetunedHistory,
      'fps',
      'FPS Over Time',
      'FPS',
      0,
      30
    );
  }, [pretrainedHistory, finetunedHistory]);

  useEffect(() => {
    drawChart(
      accuracyCanvasRef.current,
      pretrainedHistory,
      finetunedHistory,
      'accuracy',
      'Accuracy Over Time',
      'Accuracy',
      0,
      1
    );
  }, [pretrainedHistory, finetunedHistory]);

  useEffect(() => {
    drawChart(
      inferenceCanvasRef.current,
      pretrainedHistory,
      finetunedHistory,
      'inferenceTime',
      'Inference Time Over Time',
      'Time (ms)',
      0,
      200
    );
  }, [pretrainedHistory, finetunedHistory]);

  useEffect(() => {
    drawChart(
      objectsCanvasRef.current,
      pretrainedHistory,
      finetunedHistory,
      'objectCount',
      'Objects Detected Per Frame',
      'Count',
      0,
      10
    );
  }, [pretrainedHistory, finetunedHistory]);

  function drawChart(
    canvas: HTMLCanvasElement | null,
    pretrainedData: MetricsHistory[],
    finetunedData: MetricsHistory[],
    metric: keyof MetricsHistory,
    title: string,
    yLabel: string,
    minY: number,
    maxY: number
  ) {
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const padding = 40;
    const chartWidth = width - 2 * padding;
    const chartHeight = height - 2 * padding;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Background
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(0, 0, width, height);

    // Draw axes
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(padding, padding);
    ctx.lineTo(padding, height - padding);
    ctx.lineTo(width - padding, height - padding);
    ctx.stroke();

    // Draw title
    ctx.fillStyle = '#1e293b';
    ctx.font = 'bold 14px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(title, width / 2, 20);

    // Draw Y-axis label
    ctx.save();
    ctx.translate(15, height / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.font = '12px sans-serif';
    ctx.fillText(yLabel, 0, 0);
    ctx.restore();

    // Draw grid lines
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 5; i++) {
      const y = padding + (chartHeight / 5) * i;
      ctx.beginPath();
      ctx.moveTo(padding, y);
      ctx.lineTo(width - padding, y);
      ctx.stroke();

      // Y-axis labels
      const value = maxY - ((maxY - minY) / 5) * i;
      ctx.fillStyle = '#64748b';
      ctx.font = '10px sans-serif';
      ctx.textAlign = 'right';
      ctx.fillText(
        metric === 'accuracy' ? value.toFixed(2) : value.toFixed(0),
        padding - 5,
        y + 4
      );
    }

    // Draw pretrained data
    if (pretrainedData.length > 1) {
      drawLine(
        ctx,
        pretrainedData,
        metric,
        '#3b82f6',
        padding,
        chartWidth,
        chartHeight,
        minY,
        maxY
      );
    }

    // Draw finetuned data
    if (finetunedData.length > 1) {
      drawLine(
        ctx,
        finetunedData,
        metric,
        '#10b981',
        padding,
        chartWidth,
        chartHeight,
        minY,
        maxY
      );
    }

    // Draw legend
    ctx.font = '12px sans-serif';
    ctx.textAlign = 'left';
    
    ctx.fillStyle = '#3b82f6';
    ctx.fillRect(width - 150, 30, 15, 15);
    ctx.fillStyle = '#1e293b';
    ctx.fillText('Pretrained', width - 130, 42);

    ctx.fillStyle = '#10b981';
    ctx.fillRect(width - 150, 50, 15, 15);
    ctx.fillStyle = '#1e293b';
    ctx.fillText('Fine-Tuned', width - 130, 62);
  }

  function drawLine(
    ctx: CanvasRenderingContext2D,
    data: MetricsHistory[],
    metric: keyof MetricsHistory,
    color: string,
    padding: number,
    chartWidth: number,
    chartHeight: number,
    minY: number,
    maxY: number
  ) {
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.beginPath();

    data.forEach((point, index) => {
      const x = padding + (chartWidth / (data.length - 1)) * index;
      const value = point[metric] as number;
      const normalizedValue = (value - minY) / (maxY - minY);
      const y = padding + chartHeight - normalizedValue * chartHeight;

      if (index === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    });

    ctx.stroke();

    // Draw points
    ctx.fillStyle = color;
    data.forEach((point, index) => {
      const x = padding + (chartWidth / (data.length - 1)) * index;
      const value = point[metric] as number;
      const normalizedValue = (value - minY) / (maxY - minY);
      const y = padding + chartHeight - normalizedValue * chartHeight;

      ctx.beginPath();
      ctx.arc(x, y, 3, 0, 2 * Math.PI);
      ctx.fill();
    });
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-2xl font-bold text-slate-900 mb-6">Performance Visualization</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-slate-50 rounded-lg p-4">
          <canvas ref={fpsCanvasRef} width={500} height={300} />
        </div>
        
        <div className="bg-slate-50 rounded-lg p-4">
          <canvas ref={accuracyCanvasRef} width={500} height={300} />
        </div>
        
        <div className="bg-slate-50 rounded-lg p-4">
          <canvas ref={inferenceCanvasRef} width={500} height={300} />
        </div>
        
        <div className="bg-slate-50 rounded-lg p-4">
          <canvas ref={objectsCanvasRef} width={500} height={300} />
        </div>
      </div>
    </div>
  );
}
