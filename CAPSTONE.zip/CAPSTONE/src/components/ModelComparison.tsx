import React from 'react';
import { ModelMetrics } from '../types/metrics';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface ModelComparisonProps {
  pretrainedMetrics: ModelMetrics;
  finetunedMetrics: ModelMetrics;
}

export function ModelComparison({ pretrainedMetrics, finetunedMetrics }: ModelComparisonProps) {
  const renderComparison = (
    label: string,
    pretrainedValue: number,
    finetunedValue: number,
    format: 'percentage' | 'decimal' | 'number' | 'time' = 'decimal'
  ) => {
    const diff = finetunedValue - pretrainedValue;
    const isImprovement = diff > 0 && format !== 'time';
    const isWorse = diff < 0 && format !== 'time';
    
    // For time metrics, lower is better
    if (format === 'time') {
      const timeImprovement = diff < 0;
      const timeWorse = diff > 0;
      
      return (
        <tr className="border-b border-slate-200">
          <td className="py-3 px-4 font-medium text-slate-700">{label}</td>
          <td className="py-3 px-4 text-center">{pretrainedValue.toFixed(0)}ms</td>
          <td className="py-3 px-4 text-center">{finetunedValue.toFixed(0)}ms</td>
          <td className="py-3 px-4 text-center">
            <span className={`flex items-center justify-center gap-1 ${
              timeImprovement ? 'text-green-600' : timeWorse ? 'text-red-600' : 'text-slate-500'
            }`}>
              {timeImprovement ? <TrendingDown className="w-4 h-4" /> : 
               timeWorse ? <TrendingUp className="w-4 h-4" /> : 
               <Minus className="w-4 h-4" />}
              {Math.abs(diff).toFixed(0)}ms
            </span>
          </td>
        </tr>
      );
    }

    const formatValue = (value: number) => {
      if (format === 'percentage') return `${(value * 100).toFixed(1)}%`;
      if (format === 'decimal') return value.toFixed(3);
      return value.toFixed(1);
    };

    return (
      <tr className="border-b border-slate-200">
        <td className="py-3 px-4 font-medium text-slate-700">{label}</td>
        <td className="py-3 px-4 text-center">{formatValue(pretrainedValue)}</td>
        <td className="py-3 px-4 text-center">{formatValue(finetunedValue)}</td>
        <td className="py-3 px-4 text-center">
          <span className={`flex items-center justify-center gap-1 ${
            isImprovement ? 'text-green-600' : isWorse ? 'text-red-600' : 'text-slate-500'
          }`}>
            {isImprovement ? <TrendingUp className="w-4 h-4" /> : 
             isWorse ? <TrendingDown className="w-4 h-4" /> : 
             <Minus className="w-4 h-4" />}
            {format === 'percentage' ? `${Math.abs(diff * 100).toFixed(1)}%` : 
             format === 'decimal' ? Math.abs(diff).toFixed(3) : 
             Math.abs(diff).toFixed(1)}
          </span>
        </td>
      </tr>
    );
  };

  return (
    <div className="mt-8 bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-2xl font-bold text-slate-900 mb-6">Model Performance Comparison</h2>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-slate-100 border-b-2 border-slate-300">
              <th className="py-3 px-4 text-left font-semibold text-slate-700">Metric</th>
              <th className="py-3 px-4 text-center font-semibold text-slate-700">Pretrained</th>
              <th className="py-3 px-4 text-center font-semibold text-slate-700">Fine-Tuned</th>
              <th className="py-3 px-4 text-center font-semibold text-slate-700">Difference</th>
            </tr>
          </thead>
          <tbody>
            {renderComparison('Accuracy', pretrainedMetrics.accuracy, finetunedMetrics.accuracy, 'percentage')}
            {renderComparison('Precision', pretrainedMetrics.precision, finetunedMetrics.precision, 'decimal')}
            {renderComparison('Recall', pretrainedMetrics.recall, finetunedMetrics.recall, 'decimal')}
            {renderComparison('F1 Score', pretrainedMetrics.f1Score, finetunedMetrics.f1Score, 'decimal')}
            {renderComparison('mAP@0.5', pretrainedMetrics.mAP, finetunedMetrics.mAP, 'decimal')}
            {renderComparison('FPS', pretrainedMetrics.fps, finetunedMetrics.fps, 'number')}
            {renderComparison('Inference Time', pretrainedMetrics.inferenceTime, finetunedMetrics.inferenceTime, 'time')}
            {renderComparison('Latency', pretrainedMetrics.latency, finetunedMetrics.latency, 'time')}
          </tbody>
        </table>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-4">
        <div className="bg-blue-50 rounded-lg p-4">
          <h3 className="font-semibold text-blue-900 mb-2">Pretrained Model</h3>
          <p className="text-sm text-blue-700">
            MobileNetV2 + SSD trained on COCO dataset. Baseline performance for general object detection.
          </p>
        </div>
        <div className="bg-green-50 rounded-lg p-4">
          <h3 className="font-semibold text-green-900 mb-2">Fine-Tuned Model</h3>
          <p className="text-sm text-green-700">
            Fine-tuned on security dataset (~50K images). Optimized for weapon and threat detection.
          </p>
        </div>
      </div>
    </div>
  );
}

export function SystemMetrics() {
  return null;
}
