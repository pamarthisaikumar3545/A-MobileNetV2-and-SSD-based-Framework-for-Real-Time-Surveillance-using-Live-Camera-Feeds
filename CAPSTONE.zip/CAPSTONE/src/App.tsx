import React from 'react';
import { Shield, Activity } from 'lucide-react';
import { EnhancedCameraMonitor } from './components/EnhancedWebcamDetection';

function App() {
  return (
    <div className="min-h-screen bg-slate-100">
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Shield className="w-8 h-8 text-indigo-600" />
              <div>
                <h1 className="text-2xl font-bold text-slate-900">AI Security Camera System</h1>
                <p className="text-sm text-slate-600">Model Performance Evaluation & Comparison</p>
              </div>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 bg-indigo-50 rounded-lg">
              <Activity className="w-5 h-5 text-indigo-600" />
              <span className="text-sm font-semibold text-indigo-900">Live Monitoring</span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-6 p-6 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl shadow-lg text-white">
          <h2 className="text-2xl font-bold mb-2">Advanced Threat Detection System</h2>
          <p className="text-indigo-100">
            Real-time security monitoring with dynamic performance evaluation. 
            Compare Pretrained vs Fine-Tuned models with live metrics and visualization.
          </p>
          <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white/20 rounded-lg p-3">
              <p className="text-xs text-indigo-100">Real-time Detection</p>
              <p className="text-lg font-bold">24 FPS</p>
            </div>
            <div className="bg-white/20 rounded-lg p-3">
              <p className="text-xs text-indigo-100">Model Comparison</p>
              <p className="text-lg font-bold">Dual Mode</p>
            </div>
            <div className="bg-white/20 rounded-lg p-3">
              <p className="text-xs text-indigo-100">Live Metrics</p>
              <p className="text-lg font-bold">8+ KPIs</p>
            </div>
            <div className="bg-white/20 rounded-lg p-3">
              <p className="text-xs text-indigo-100">Threat Detection</p>
              <p className="text-lg font-bold">AI-Powered</p>
            </div>
          </div>
        </div>

        <EnhancedCameraMonitor />

        <div className="mt-8 p-6 bg-white rounded-xl shadow-lg">
          <h3 className="text-lg font-semibold text-slate-900 mb-4">System Capabilities</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 bg-indigo-600 rounded-full mt-2"></div>
              <div>
                <p className="font-semibold text-slate-800">Dual Model Architecture</p>
                <p className="text-sm text-slate-600">Switch between Pretrained and Fine-Tuned models dynamically</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 bg-indigo-600 rounded-full mt-2"></div>
              <div>
                <p className="font-semibold text-slate-800">Real-time Performance Metrics</p>
                <p className="text-sm text-slate-600">FPS, accuracy, precision, recall, F1 score, mAP tracking</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 bg-indigo-600 rounded-full mt-2"></div>
              <div>
                <p className="font-semibold text-slate-800">Live Visualization</p>
                <p className="text-sm text-slate-600">Performance charts with historical data comparison</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 bg-indigo-600 rounded-full mt-2"></div>
              <div>
                <p className="font-semibold text-slate-800">Threat Classification</p>
                <p className="text-sm text-slate-600">Weapon detection with confidence scoring and alerts</p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-white border-t border-slate-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <p className="text-center text-sm text-slate-600">
            AI Security Camera System - Model Performance Evaluation Platform
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;