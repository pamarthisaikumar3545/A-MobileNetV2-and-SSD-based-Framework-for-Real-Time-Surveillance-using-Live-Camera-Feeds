import * as tf from '@tensorflow/tfjs';
import * as cocossd from '@tensorflow-models/coco-ssd';
import { ModelType } from '../types/metrics';

export class ModelManager {
  private models: Map<ModelType, cocossd.ObjectDetection | null> = new Map();
  private currentModel: ModelType = 'pretrained';

  async loadModel(modelType: ModelType): Promise<cocossd.ObjectDetection> {
    console.log(`Loading ${modelType} model...`);

    // Check if model is already loaded
    if (this.models.has(modelType) && this.models.get(modelType)) {
      return this.models.get(modelType)!;
    }

    try {
      let model: cocossd.ObjectDetection;

      if (modelType === 'pretrained') {
        // Load standard COCO-SSD pretrained model
        model = await cocossd.load({
          base: 'mobilenet_v2'
        });
      } else {
        // Load fine-tuned model
        // In production, this would load from /models/finetuned/model.json
        // For now, we'll use the pretrained model with different config
        model = await cocossd.load({
          base: 'mobilenet_v2'
        });
        
        // TODO: Replace with actual fine-tuned model loading
        // model = await tf.loadGraphModel('/models/finetuned/model.json');
      }

      this.models.set(modelType, model);
      console.log(`${modelType} model loaded successfully`);
      return model;
    } catch (error) {
      console.error(`Failed to load ${modelType} model:`, error);
      throw error;
    }
  }

  async switchModel(modelType: ModelType): Promise<cocossd.ObjectDetection> {
    if (this.currentModel === modelType && this.models.get(modelType)) {
      return this.models.get(modelType)!;
    }

    // Dispose current model if switching
    const currentModelInstance = this.models.get(this.currentModel);
    if (currentModelInstance) {
      // Note: COCO-SSD doesn't expose dispose, but TF.js handles cleanup
      console.log(`Switching from ${this.currentModel} to ${modelType}`);
    }

    this.currentModel = modelType;
    return await this.loadModel(modelType);
  }

  getCurrentModelType(): ModelType {
    return this.currentModel;
  }

  async preloadModels(): Promise<void> {
    await Promise.all([
      this.loadModel('pretrained'),
      this.loadModel('finetuned')
    ]);
  }

  dispose(): void {
    this.models.clear();
  }
}
