export interface Detection {
  area: number[];
  type: string;
  confidence: number;
  time: number;
}

export interface DetectionResult {
  bbox: number[];
  class: string;
  score: number;
}

export interface MotionData {
  isMoving: boolean;
  intensity: number;
}