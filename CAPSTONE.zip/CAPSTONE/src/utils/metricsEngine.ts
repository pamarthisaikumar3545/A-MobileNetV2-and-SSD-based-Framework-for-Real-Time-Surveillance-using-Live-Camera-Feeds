import { ModelMetrics, MetricsHistory } from '../types/metrics';

export class MetricsEngine {
  private metrics: ModelMetrics;
  private history: MetricsHistory[] = [];
  private startTime: number = Date.now();
  private frameCount: number = 0;
  private readonly maxHistorySize = 60;

  constructor() {
    this.metrics = this.initializeMetrics();
  }

  private initializeMetrics(): ModelMetrics {
    return {
      accuracy: 0,
      precision: 0,
      recall: 0,
      f1Score: 0,
      mAP: 0,
      fps: 0,
      inferenceTime: 0,
      latency: 0,
      objectsDetected: 0,
      threatAlerts: 0,
      totalFrames: 0,
      truePositives: 0,
      falsePositives: 0,
      falseNegatives: 0
    };
  }

  updateFrame(inferenceTime: number, detections: number, threats: number): void {
    this.frameCount++;
    this.metrics.totalFrames++;
    this.metrics.inferenceTime = inferenceTime;
    this.metrics.objectsDetected = detections;
    this.metrics.threatAlerts = threats;

    // Calculate FPS
    const elapsed = (Date.now() - this.startTime) / 1000;
    this.metrics.fps = this.frameCount / elapsed;

    // Update latency (inference + processing overhead)
    this.metrics.latency = inferenceTime + 20;
  }

  updateDetectionMetrics(
    truePositives: number,
    falsePositives: number,
    falseNegatives: number
  ): void {
    this.metrics.truePositives += truePositives;
    this.metrics.falsePositives += falsePositives;
    this.metrics.falseNegatives += falseNegatives;

    // Calculate precision
    const totalPositives = this.metrics.truePositives + this.metrics.falsePositives;
    this.metrics.precision = totalPositives > 0 
      ? this.metrics.truePositives / totalPositives 
      : 0;

    // Calculate recall
    const totalActual = this.metrics.truePositives + this.metrics.falseNegatives;
    this.metrics.recall = totalActual > 0 
      ? this.metrics.truePositives / totalActual 
      : 0;

    // Calculate F1 score
    if (this.metrics.precision + this.metrics.recall > 0) {
      this.metrics.f1Score = 
        (2 * this.metrics.precision * this.metrics.recall) / 
        (this.metrics.precision + this.metrics.recall);
    }

    // Calculate accuracy
    const total = this.metrics.truePositives + 
                  this.metrics.falsePositives + 
                  this.metrics.falseNegatives;
    this.metrics.accuracy = total > 0 
      ? this.metrics.truePositives / total 
      : 0;

    // Estimate mAP (simplified)
    this.metrics.mAP = this.metrics.precision * 0.95;
  }

  addHistoryPoint(): void {
    this.history.push({
      timestamp: Date.now(),
      fps: this.metrics.fps,
      accuracy: this.metrics.accuracy,
      inferenceTime: this.metrics.inferenceTime,
      objectCount: this.metrics.objectsDetected
    });

    if (this.history.length > this.maxHistorySize) {
      this.history.shift();
    }
  }

  getMetrics(): ModelMetrics {
    return { ...this.metrics };
  }

  getHistory(): MetricsHistory[] {
    return [...this.history];
  }

  reset(): void {
    this.metrics = this.initializeMetrics();
    this.history = [];
    this.startTime = Date.now();
    this.frameCount = 0;
  }
}
