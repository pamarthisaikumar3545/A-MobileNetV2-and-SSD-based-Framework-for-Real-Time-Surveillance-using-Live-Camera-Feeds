"""
Create a Demo Fine-Tuned Model
This script creates a simple demo model for testing purposes.
For production, use train_finetuned_model.py with your actual dataset.
"""

import tensorflow as tf
import tensorflowjs as tfjs
import os

def create_demo_model():
    """Create a simple demo model that mimics the structure"""
    print("Creating demo fine-tuned model...")
    
    # Create a simple MobileNetV2-based model
    base_model = tf.keras.applications.MobileNetV2(
        input_shape=(416, 416, 3),
        include_top=False,
        weights='imagenet'
    )
    
    # Add classification head
    x = base_model.output
    x = tf.keras.layers.GlobalAveragePooling2D()(x)
    x = tf.keras.layers.Dense(256, activation='relu')(x)
    x = tf.keras.layers.Dropout(0.3)(x)
    predictions = tf.keras.layers.Dense(8, activation='softmax')(x)
    
    model = tf.keras.Model(inputs=base_model.input, outputs=predictions)
    
    # Compile (required for saving)
    model.compile(
        optimizer='adam',
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    
    print("Model created successfully")
    return model

def export_model(model, output_path='../public/models/finetuned'):
    """Export model to TensorFlow.js format"""
    print(f"Exporting to: {output_path}")
    
    # Create directory
    os.makedirs(output_path, exist_ok=True)
    
    # Convert to TensorFlow.js
    tfjs.converters.save_keras_model(model, output_path)
    
    print("✓ Model exported successfully!")
    print(f"\nFiles created in {output_path}:")
    for file in os.listdir(output_path):
        size = os.path.getsize(os.path.join(output_path, file)) / (1024*1024)
        print(f"  - {file} ({size:.2f} MB)")

def main():
    print("=" * 60)
    print("Demo Fine-Tuned Model Creator")
    print("=" * 60)
    print("\nThis creates a demo model for testing the dual-model system.")
    print("For production, train a real model using train_finetuned_model.py\n")
    
    # Create model
    model = create_demo_model()
    
    # Export
    export_model(model)
    
    print("\n" + "=" * 60)
    print("Demo Model Ready!")
    print("=" * 60)
    print("\nNext steps:")
    print("1. Restart your web application (npm run dev)")
    print("2. Click the 'Fine-Tuned Model' button")
    print("3. The system will now load your custom model")
    print("\nNote: This is a demo model. For real security detection,")
    print("      train a proper model using your security dataset.")

if __name__ == '__main__':
    main()
