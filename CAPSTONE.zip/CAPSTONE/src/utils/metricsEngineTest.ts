import { MetricsEngine } from './metricsEngine';

// Simple test to verify metrics engine works
export function testMetricsEngine() {
  console.log('=== Testing Metrics Engine ===');
  
  const engine = new MetricsEngine();
  
  // Simulate some frames
  for (let i = 0; i < 10; i++) {
    engine.updateFrame(100, 3, 1);
    engine.updateDetectionMetrics(2, 1, 0);
  }
  
  const metrics = engine.getMetrics();
  console.log('Test Metrics:', {
    fps: metrics.fps.toFixed(1),
    accuracy: (metrics.accuracy * 100).toFixed(1) + '%',
    precision: metrics.precision.toFixed(3),
    recall: metrics.recall.toFixed(3),
    f1Score: metrics.f1Score.toFixed(3),
    totalFrames: metrics.totalFrames
  });
  
  console.log('=== Test Complete ===');
  return metrics;
}
